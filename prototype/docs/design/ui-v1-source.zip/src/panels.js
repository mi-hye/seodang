import { episode, expressions } from "./content.js";
import { icon, button, dog, expressionCard } from "./ui.js";
export function renderPanel(kind, state, id) {
  const e = state.episode;
  let title = "",
    body = "";
  if (kind === "settings") {
    title = "읽기·소리 설정";
    body = `<p class="muted">편안한 속도로 읽어 보세요.</p><label class="setting"><span>글자 크기</span><select data-setting="textScale"><option value="1" ${state.settings.textScale === 1 ? "selected" : ""}>기본</option><option value="1.2" ${state.settings.textScale === 1.2 ? "selected" : ""}>크게</option></select></label><label class="setting"><span>화면 움직임</span><select data-setting="motion"><option value="system" ${state.settings.motion === "system" ? "selected" : ""}>기기 설정 따르기</option><option value="off" ${state.settings.motion === "off" ? "selected" : ""}>항상 멈추기</option></select></label><label class="setting"><span>소리 사용</span><input type="checkbox" data-setting="sound" ${state.settings.sound ? "checked" : ""}></label><p class="muted">음성 파일은 준비 중이에요.<br>지금은 글을 읽으며 모든 과정을 진행할 수 있어요.</p>${button("설정 마치기", "close")}`;
  }
  if (kind === "notebook") {
    title = "단서 노트";
    body = `<span class="eyebrow">모은 단서 ${e.clues.length} / 2</span>${
      e.clues.length
        ? episode.clues
            .filter((c) => e.clues.includes(c.id))
            .map(
              (c) =>
                `<div class="notebook-clue"><span>${c.title}</span>${expressionCard(
                  expressions.find((x) => x.id === c.expressionId),
                  { sound: state.settings.sound },
                )}</div>`,
            )
            .join("")
        : '<p class="empty-note">아직 모은 단서가 없어요.<br>카페의 메모를 눌러 조사해 보세요.</p>'
    }<h3>이번에 만난 표현</h3>${
      state.encountered.length
        ? expressions
            .filter((x) => state.encountered.includes(x.id))
            .map(
              (x) =>
                `<details class="learned-line"><summary lang="ja">${x.text}</summary><p>${x.meaning}</p></details>`,
            )
            .join("")
        : '<p class="muted">표현을 익히면 여기에 기록돼요.</p>'
    }${e.step === "investigate" ? button(`${icon("help")} 단계별 힌트`, "hint", "secondary") : ""}${button("읽던 곳으로 돌아가기", "close")}`;
  }
  if (kind === "clue") {
    const c = episode.clues.find((c) => c.id === id);
    title = c.title;
    body = `<span class="eyebrow">손님이 남긴 메모 · 노트에 기록함</span>${expressionCard(
      expressions.find((x) => x.id === c.expressionId),
      { sound: state.settings.sound },
    )}${dog("모르는 말은 뜻을 펼쳐 봐도 괜찮아.", "explain")}${button("조사 계속하기", "close")}`;
  }
  if (kind === "hint") {
    title = "서당개의 도움";
    body = `${dog("한 번에 하나씩 살펴보자.<br>도움을 받아도 괜찮아.", "think")}<ol class="hints">${episode.hints
      .slice(0, e.hintLevel)
      .map((h) => `<li>${h}</li>`)
      .join(
        "",
      )}</ol>${button(e.hintLevel < 3 ? "도움 한 단계 더 보기" : "모든 도움을 확인했어요", "more-hint", "secondary", e.hintLevel >= 3 ? "disabled" : "")}${button("사건으로 돌아가기", "close")}`;
  }
  if (kind === "restart") {
    title = "사건을 다시 시작할까요?";
    body = `<p>이 사건의 진행·단서·이해 확인을 처음으로 돌려요. 이미 만난 표현과 읽기 설정은 남겨 둘게요.</p>${button("사건 처음부터 시작", "confirm-restart")}${button("이어 읽기", "close", "secondary")}`;
  }
  if (kind === "reset") {
    title = "이 기기의 기록을 지울까요?";
    body = `<p>이 프로토타입의 사건 진행, 표현 노트, 설정이 삭제돼요. 되돌릴 수 없어요.</p>${button("기록 먼저 내보내기", "export", "secondary")}${button("프로토타입 기록 삭제", "confirm-reset", "primary destructive")}${button("취소", "close", "text-button")}<p role="status"></p>`;
  }
  return `<div class="panel-head"><h2 id="panel-title">${title}</h2>${button(icon("close"), "close", "icon-button", 'aria-label="닫기"')}</div><div class="panel-body">${body}</div>`;
}
