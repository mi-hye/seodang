export const assets = {
  hanok: { src: "assets/hanok.svg", status: "temporary" },
  cafe: { src: "assets/cafe.svg", status: "temporary" },
  mascot: {
    idle: "assets/dog.svg",
    explain: "assets/dog.svg",
    listen: "assets/dog.svg",
    think: "assets/dog.svg",
    encourage: "assets/dog.svg",
    celebrate: "assets/dog.svg",
    status: "temporary",
  },
};
export const audioManifest = Object.fromEntries(
  [
    ["case01.blue-bag.ja", "ja-JP", "learning", "あおい かばん"],
    ["case01.near-window.ja", "ja-JP", "learning", "まどの そば"],
    ["guide.intro.ko", "ko-KR", "guide", "메모를 같이 읽어볼까?"],
  ].map(([id, locale, role, text]) => [
    id,
    {
      id,
      locale,
      role,
      text,
      audioFile: null,
      status: "missing",
      productionMethod: null,
      rightsReviewed: false,
      languageReviewed: false,
    },
  ]),
);
export class AudioPlayer {
  constructor(factory = (src) => new Audio(src)) {
    this.factory = factory;
    this.current = null;
    this.generation = 0;
  }
  stop() {
    this.generation++;
    if (this.current) {
      this.current.pause();
      this.current.currentTime = 0;
      this.current = null;
    }
  }
  async play(entry, enabled, onError) {
    this.stop();
    if (!enabled || !entry?.audioFile || entry.status !== "ready") return;
    const generation = this.generation;
    try {
      this.current = this.factory(entry.audioFile);
      this.current.onerror = () => {
        if (this.generation === generation) {
          this.stop();
          onError("음성을 재생하지 못했어요. 글을 읽으며 계속할 수 있어요.");
        }
      };
      await this.current.play();
    } catch {
      if (this.generation === generation) {
        this.stop();
        onError("음성을 재생하지 못했어요. 글을 읽으며 계속할 수 있어요.");
      }
    }
  }
}
