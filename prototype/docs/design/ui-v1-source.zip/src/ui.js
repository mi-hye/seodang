import { assets, audioManifest } from "./media.js";
export const esc = (s) =>
  String(s).replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const paths = {
  home: "M3 10L12 3l9 7v11h-6v-7H9v7H3Z",
  book: "M12 5v16M12 5C8 2 4 3 2 4v15c4-2 7-1 10 2 3-3 6-4 10-2V4c-3-2-7-2-10 1Z",
  leaf: "M5 20C2 8 12 2 21 3c0 10-5 17-16 17ZM5 20l10-10",
  settings:
    "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8ZM12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2",
  arrow: "M5 12h14m-5-5 5 5-5 5",
  back: "M19 12H5m5-5-5 5 5 5",
  close: "m6 6 12 12M6 18 18 6",
  check: "m5 12 4 4L19 6",
  sound: "M11 4 5 9H2v6h3l6 5V4Zm5 4q5 4 0 8m3-11q8 7 0 14",
  note: "M5 3h15v18H5ZM2 7h6M2 12h6M2 17h6m9-10h5m-5 5h5",
  help: "M9 8c0-5 8-5 8 0 0 3-5 2-5 6m0 3v1",
  pause: "M8 5v14M16 5v14",
  play: "m7 4 13 8-13 8Z",
  cup: "M4 6h13v10q0 5-6 5T4 16ZM17 7h3q5 6-3 6M6 2v2m5-2v2",
};
export const icon = (name) =>
  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${`<path d="${paths[name] || paths.leaf}"/>`}</svg>`;
export const button = (label, action, cls = "primary", extra = "") =>
  `<button class="${cls}" data-action="${action}" ${extra}>${label}</button>`;
export function dog(text = "", mood = "idle") {
  return `<div class="guide"><img src="${assets.mascot[mood]}" alt="서당개 · 임시 캐릭터" width="68" height="73"><div><span class="guide-name">서당개 <small>임시</small></span>${text ? `<p>${text}</p>` : ""}</div></div>`;
}
export function bag(color) {
  return `<svg class="bag-art" viewBox="0 0 100 100" aria-hidden="true"><ellipse cx="50" cy="91" rx="35" ry="6" fill="#332c22" opacity=".12"/><path d="M34 28V21Q50 6 66 21v8" fill="none" stroke="${color === "red" ? "#915c50" : "#496779"}" stroke-width="7"/><path d="M25 27Q50 20 75 27l9 56q-34 13-68 0Z" fill="${color === "red" ? "#b77363" : "#648b9f"}"/><path d="M25 29Q50 37 75 29M25 57H75L72 79H28Z" fill="none" stroke="${color === "red" ? "#d69a83" : "#96b6bd"}" stroke-width="3"/><path d="M24 29 17 77M76 29l7 48" stroke="#ead7af" stroke-width="2"/><circle cx="72" cy="39" r="3" fill="#e9d6a8"/></svg>`;
}
export function audioButton(id, sound) {
  const a = audioManifest[id];
  return a?.audioFile && a.status === "ready"
    ? button(
        `${icon("sound")} 듣기`,
        "audio",
        "text-button",
        `data-id="${id}" ${sound ? "" : 'disabled title="소리가 꺼져 있어요"'}`,
      )
    : '<span class="audio-missing">음성 준비 중 · 읽기로 진행</span>';
}
export function expressionCard(
  e,
  { meaning = false, sound = true, beginner = false } = {},
) {
  return `<article class="expression"><span class="eyebrow">일본어 표현</span><h3 lang="ja">${e.text}</h3>${meaning ? `<p>${e.meaning}</p>` : `<details><summary>뜻 확인하기</summary><p>${e.meaning}</p></details>`}<div class="expression-parts">${meaning ? e.parts.map(([ja, ko]) => `<span><b lang="ja">${ja}</b> ${ko}</span>`).join("") : ""}</div><details><summary>${beginner ? "글자와 읽는 법 도움" : "읽는 법 보기"}</summary><p lang="ja-Latn">${e.reading}</p><p>${e.help}</p><small>익숙해지면 도움을 접고 읽어 보세요. 일반 표기: <span lang="ja">${e.natural}</span></small></details>${audioButton(`case01.${e.id}.ja`, sound)}</article>`;
}
