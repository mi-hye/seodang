export const course = {
  id: "ko-ja",
  guideLocale: "ko-KR",
  learningLocale: "ja-JP",
  status: "provisional",
};
export const expressions = [
  {
    id: "blue-bag",
    text: "あおい かばん",
    natural: "あおいかばん",
    meaning: "파란 가방",
    reading: "aoi kaban",
    parts: [
      ["あおい", "파란"],
      ["かばん", "가방"],
    ],
    help: "あ는 ‘아’, お는 ‘오’, い는 ‘이’로 읽어요. あおい는 파란색을 나타내요.",
  },
  {
    id: "near-window",
    text: "まどの そば",
    natural: "まどのそば",
    meaning: "창문 옆 · 창문 가까이",
    reading: "mado no soba",
    parts: [
      ["まど", "창문"],
      ["〜の そば", "~의 옆, 가까이"],
    ],
    help: "ま는 ‘마’, ど는 ‘도’로 읽어요. まど는 창문, の는 말을 연결하고, そば는 옆이나 가까이를 뜻해요.",
  },
];
export const episode = {
  id: "case-01",
  version: 1,
  title: "카페에 남겨진 가방",
  intro: [
    {
      speaker: "카페 직원",
      text: "손님이 가방을 두고 가셨어요. 찾으러 오시기 전에 어느 가방인지 확인해 주실래요?",
    },
    {
      speaker: "서당개",
      text: "손님이 남긴 메모가 있대. 먼저 짧은 표현 두 개를 익히고, 함께 찾아보자.",
    },
  ],
  objects: [
    {
      id: "bag-window-red",
      color: "red",
      place: "window",
      label: "창문 옆 빨간 가방",
    },
    {
      id: "bag-door-blue",
      color: "blue",
      place: "door",
      label: "문 옆 파란 가방",
    },
    {
      id: "bag-window-blue",
      color: "blue",
      place: "window",
      label: "창문 옆 파란 가방",
    },
  ],
  clues: [
    {
      id: "color",
      expressionId: "blue-bag",
      title: "메모 앞면",
      text: "あおい かばん",
    },
    {
      id: "position",
      expressionId: "near-window",
      title: "메모 뒷면",
      text: "まどの そば",
    },
  ],
  hints: [
    "색을 나타내는 あおい와 위치를 나타내는 まどの そば를 함께 봐요.",
    "あおい는 파란, まど는 창문이에요. そば는 옆이나 가까이라는 뜻이에요.",
    "창문 옆에 있는 파란 가방이 두 조건을 모두 만족해요.",
  ],
  transfer: {
    prompt: "まどの そば",
    objects: [
      { id: "book", label: "문 옆의 책", place: "door", symbol: "book" },
      { id: "cup", label: "창문 옆의 컵", place: "window", symbol: "cup" },
      {
        id: "plant",
        label: "방 가운데 화분",
        place: "center",
        symbol: "plant",
      },
    ],
    answer: "cup",
  },
};
