import { episode, expressions } from "./content.js";
import { freshState, reduce } from "./engine.js";
import { load, save, reset, STORAGE_KEY } from "./storage.js";
import { assets, AudioPlayer, audioManifest } from "./media.js";
import { icon, button, dog, bag, expressionCard, esc } from "./ui.js";
const app = document.querySelector("#app"),
  panel = document.querySelector("#panel");
let storage;
try {
  storage = window.localStorage;
} catch {
  storage = {
    getItem() {
      throw Error();
    },
    setItem() {
      throw Error();
    },
    removeItem() {
      throw Error();
    },
  };
}
let loaded = load(storage),
  state = loaded.state,
  storageError = loaded.error,
  blocked = loaded.blocked;
let view = state.onboarded ? "home" : "start",
  panelKind = "",
  panelTrigger = null,
  lastAdvance = -Infinity,
  toast = "",
  support = state.support;
const player = new AudioPlayer();
const progress = () =>
  ({ intro: 0, learn: 1, investigate: 2, solved: 3, transfer: 4, summary: 5 })[
    state.episode.step
  ];
const status = () =>
  state.episode.step === "summary"
    ? "해결한 이야기"
    : state.episode.solved
      ? "이해 확인 남음"
      : state.episode.started
        ? "진행 중"
        : "아직 시작하지 않은 이야기";
function commit(action) {
  state = reduce(state, action);
  if (!blocked) storageError = save(storage, state);
}
function navigate(next) {
  player.stop();
  view = next;
  toast = "";
  render(true);
}
function top(title, back = false) {
  return `<header class="topbar">${back ? button(icon("back"), "home", "icon-button", 'aria-label="홈으로 나가기"') : '<span class="wordmark">서당<span>✳</span></span>'}<span class="top-title">${title}</span>${button(icon("settings"), "settings", "icon-button", 'aria-label="설정 열기"')}</header>`;
}
function tabs() {
  return `<nav class="tabs" aria-label="주 메뉴">${[
    ["home", "home", "홈"],
    ["stories", "book", "이야기"],
    ["review", "leaf", "복습"],
    ["my", "note", "내 학습"],
  ]
    .map(([id, i, t]) =>
      button(
        `${icon(i)}<span>${t}</span>`,
        id,
        view === id ? "tab active" : "tab",
        `aria-current="${view === id ? "page" : "false"}"`,
      ),
    )
    .join("")}</nav>`;
}
function start() {
  return `<main class="start"><img class="start-art" src="${assets.hanok.src}" alt="노을빛 한옥 골목 임시 일러스트"><div class="start-heading"><h1>서당<span>✳</span></h1><div class="title-line"></div></div><div class="petals" aria-hidden="true"><i></i><i></i><i></i><i></i></div><div class="start-bottom"><img class="start-dog" src="${assets.mascot.idle}" alt="서당개 · 임시 디자인" width="105" height="113">${button(`시작하기 ${icon("arrow")}`, "start")}<span class="prototype-note">플레이 프로토타입 · 임시 아트</span></div>${button(icon(state.settings.motion === "off" ? "play" : "pause"), "motion", "motion-button", `aria-label="${state.settings.motion === "off" ? "시작 화면 움직임 켜기" : "시작 화면 움직임 멈추기"}"`)}</main>`;
}
function onboarding() {
  return `${top("처음 만나는 서당")}<main class="page onboarding"><span class="eyebrow">일본어 학습 체험판 · 한국어 안내</span><h1>어떤 도움으로<br>시작할까요?</h1>${dog("처음 보는 글자여도 괜찮아.<br>짧은 표현부터 같이 읽어 보자.")}<div class="support-options">${[
    ["beginner", "글자부터 도움받기", "일본어가 처음이거나, 가나가 낯설어요."],
    ["phrase", "짧은 표현으로 시작하기", "글자는 조금 읽을 수 있어요."],
  ]
    .map(
      ([id, t, d]) =>
        `<button class="support ${support === id ? "selected" : ""}" data-action="support" data-id="${id}" aria-pressed="${support === id}"><span class="radio"></span><span><strong>${t}</strong><small>${d}</small></span></button>`,
    )
    .join(
      "",
    )}</div><p class="muted">한 편의 이야기로 색과 위치 표현을 만나요.<br>반대 방향의 한국어 학습은 준비 중이에요.</p>${button(`이야기 만나러 가기 ${icon("arrow")}`, "onboard")}</main>`;
}
function caseCard() {
  return `<article class="case-card"><div class="case-art"><img src="${assets.cafe.src}" alt="햇살이 드는 카페 일러스트"><span class="case-number">사건 01</span></div><div class="case-content"><span class="eyebrow">${status()}</span><h2>카페에 남겨진 가방</h2><p>작은 메모 두 장, 가방의 주인을 찾는 단서.</p><div class="case-meta"><span>입문 · 색과 위치</span><span>약 3–5분</span></div>${state.episode.started ? `<div class="progress-track" role="progressbar" aria-label="사건 진행" aria-valuemin="0" aria-valuemax="5" aria-valuenow="${progress()}"><span style="width:${progress() * 20}%"></span></div>` : ""}${button(`${state.episode.step === "summary" ? "표현 다시 보기" : state.episode.started ? "이어서 하기" : "사건 01 시작하기"} ${icon("arrow")}`, state.episode.step === "summary" ? "review" : "play")}</div></article>`;
}
function home() {
  return `${top("일본어 첫걸음")}<main class="page home"><div class="section-label">작은 이야기, 오늘의 일본어</div><h1>이야기 속으로<br>한 걸음.</h1>${dog(state.episode.solved ? "가방이 주인을 찾았어. 우리가 만난 표현도 다시 볼까?" : "손님이 가방을 두고 갔대.<br>메모를 같이 읽어볼까?")}${caseCard()}<div class="section-row"><h2>나의 표현 노트</h2>${button(`${state.encountered.length}개 ${icon("arrow")}`, "review", "text-button")}</div><p class="muted">${state.encountered.length ? "이야기에서 만난 표현을 다시 펼쳐 보세요." : "사건에서 만난 표현이 여기에 쌓여요."}</p><div class="home-footer">${icon("leaf")} 서두르지 않아도 괜찮아요.</div></main>${tabs()}`;
}
function stories() {
  return `${top("이야기")}<main class="page"><span class="eyebrow">일상에서 발견하는 일본어</span><h1>어떤 이야기를<br>만나 볼까요?</h1>${caseCard()}<article class="coming"><span>02</span><div><h3>잘못 전달된 음료</h3><p>주문과 정중한 표현</p></div><small>준비 중</small></article><article class="coming"><span>03</span><div><h3>길을 묻는 손님</h3><p>방향과 장소</p></div><small>준비 중</small></article></main>${tabs()}`;
}
function review() {
  return `${top("표현 노트")}<main class="page"><span class="eyebrow">이번에 만난 표현 · ${state.encountered.length}개</span><h1>한 번 더,<br>내 말이 되도록.</h1>${
    state.encountered.length
      ? `<p class="muted">한 번의 만남은 시작이에요. 뜻을 떠올린 뒤 펼쳐 보세요.</p>${expressions
          .filter((e) => state.encountered.includes(e.id))
          .map((e) => expressionCard(e, { sound: state.settings.sound }))
          .join(
            "",
          )}${state.episode.step === "summary" ? button("사건 다시 플레이", "restart", "secondary") : button("이야기 이어서 하기", "play")}`
      : `${dog("아직 만난 표현이 없어.<br>첫 이야기를 시작하면 함께 기록할게.")}${button("첫 이야기 시작하기", "play")}`
  }</main>${tabs()}`;
}
function my() {
  return `${top("내 학습")}<main class="page"><span class="eyebrow">이 기기의 학습 기록</span><h1>조금씩 쌓이는<br>나의 이야기.</h1><div class="stats"><div><strong>${state.episode.solved ? 1 : 0}</strong><span>해결한 사건</span></div><div><strong>${state.encountered.length}</strong><span>만난 표현</span></div></div><article class="paper"><h3>카페에 남겨진 가방</h3><p>${status()}</p><p>이해 확인: ${state.episode.transfer === "passed" ? "다른 배치에서 확인했어요" : state.episode.transfer === "retry" ? "다시 살펴보는 중" : "아직 확인하지 않았어요"}</p><small>사건 해결과 표현 숙달은 서로 달라요.</small></article>${button(`${icon("settings")} 읽기·소리 설정`, "settings", "secondary")}${button("기록 내보내기", "export", "text-button")}${button("이 기기의 기록 초기화", "reset", "text-button danger")}<p class="muted">기록은 이 브라우저에만 저장돼요.<br>다른 기기와 자동으로 동기화되지 않아요.</p><details class="asset-info"><summary>체험판 제작 상태</summary><p>한국어 안내 → 일본어 학습, 한 사건을 체험할 수 있어요. 배경과 서당개는 임시 일러스트이며 최종 외형은 미정이에요. 음성은 준비 중이에요.</p></details></main>${tabs()}`;
}
function scene() {
  return `<div class="scene"><img src="${assets.cafe.src}" alt="왼쪽에 창문, 오른쪽에 문이 있는 카페"><span class="scene-tag">골목의 작은 카페</span><div class="scene-caption">늦은 오후, 손님이 떠난 자리.</div></div>`;
}
function investigation() {
  const e = state.episode;
  return `<div class="investigation"><div class="room-labels"><span>창문</span><span>문</span></div><div class="room"><img src="${assets.cafe.src}" alt="왼쪽 창문과 오른쪽 출입문이 있는 카페"><div class="bag-position window-red">${bagButton(episode.objects[0])}</div><div class="bag-position door-blue">${bagButton(episode.objects[1])}</div><div class="bag-position window-blue">${bagButton(episode.objects[2])}</div></div><div class="memo-row">${episode.clues.map((c) => button(`${icon("note")}<span>${c.title}<small>${e.clues.includes(c.id) ? "기록함 ✓" : "눌러서 조사"}</small></span>`, "clue", "memo", `data-id="${c.id}"`)).join("")}</div></div>`;
}
function bagButton(o) {
  return `<button class="bag-target ${state.episode.selected === o.id ? "selected" : ""}" data-action="select" data-id="${o.id}" aria-label="${o.label}" aria-pressed="${state.episode.selected === o.id}">${bag(o.color)}<span>${o.place === "window" ? "창문 옆" : "문 옆"}</span><small>${o.color === "red" ? "빨간 가방" : "파란 가방"}</small></button>`;
}
function transferScene() {
  return `<div class="transfer-room"><div class="transfer-door">문</div><div class="transfer-window">창문<span></span></div><div class="transfer-objects">${episode.transfer.objects.map((o) => button(`<span class="object-symbol">${o.symbol === "cup" ? icon("cup") : o.symbol === "book" ? icon("book") : icon("leaf")}</span><span>${o.label}</span>`, "transfer", "transfer-object " + o.place, `data-id="${o.id}" ${state.episode.transfer === "passed" ? "disabled" : ""}`)).join("")}</div></div>`;
}
function play() {
  const e = state.episode;
  const labels = [
    "이야기",
    "표현 익히기",
    "단서 조사",
    "가방 전달",
    "다시 써 보기",
    "마무리",
  ];
  let body = "";
  if (e.step === "intro")
    body = `${scene()}<section class="reading"><span class="speaker">${episode.intro[e.dialogue].speaker}</span><h2>${e.dialogue ? "함께 읽어 볼까?" : "이 가방, 누구의 것일까요?"}</h2><p class="dialogue">${episode.intro[e.dialogue].text}</p>${e.dialogue ? dog("메모를 읽는 데 필요한 말은 딱 두 가지야.") : ""}${button(`${e.dialogue ? "표현 익히기" : "이야기 계속"} ${icon("arrow")}`, "next")}</section>`;
  if (e.step === "learn")
    body = `<section class="reading"><span class="eyebrow">표현 ${e.lesson + 1} / 2</span><h1>${e.lesson ? "어디에 있을까요?" : "어떤 가방일까요?"}</h1>${dog(e.lesson ? "まど는 창문이야. 가까이에 있다는 말을 붙여 보자." : "색을 나타내는 말 다음에 물건 이름을 붙이면 돼.", "explain")}${expressionCard(expressions[e.lesson], { meaning: true, sound: state.settings.sound, beginner: state.support === "beginner" })}${button(`${e.lesson ? "메모 조사하러 가기" : "다음 표현"} ${icon("arrow")}`, "next")}</section>`;
  if (e.step === "investigate")
    body = `${investigation()}<section class="reading"><div class="section-row"><span class="eyebrow">수집한 단서 ${e.clues.length} / 2</span>${button(`${icon("help")} 도움`, "hint", "text-button")}</div><h2>${e.selected ? "이 가방을 전달할까요?" : "메모를 읽고 가방을 찾아요."}</h2><p>${e.selected ? episode.objects.find((o) => o.id === e.selected).label : "메모 앞면과 뒷면을 조사한 뒤, 가방을 눌러 선택해 주세요."}</p>${e.feedback ? `<div class="feedback" role="status">${esc(e.feedback)}</div>` : ""}${button(`선택한 가방 전달하기 ${icon("arrow")}`, "submit")}${button(`${icon("note")} 단서 노트 ${e.clues.length}/2`, "notebook", "secondary")}</section>`;
  if (e.step === "solved")
    body = `${scene()}<section class="reading"><span class="eyebrow">사건 해결</span><h1>가방이 주인을<br>찾았어요.</h1><blockquote>“맞아요, 이 가방이에요.<br>찾아 주셔서 정말 감사합니다!”<cite>가방을 찾으러 온 손님</cite></blockquote>${dog("색도 위치도, 두 단서를 함께 읽어 냈어!", "celebrate")}<p><b lang="ja">あおい かばん</b>은 파란 가방,<br><b lang="ja">まどの そば</b>는 창문 가까이.<br>그래서 창문 옆의 파란 가방이 맞아요.</p>${button(`다른 자리에서도 찾아볼까요? ${icon("arrow")}`, "next")}</section>`;
  if (e.step === "transfer")
    body = `<section class="reading"><span class="eyebrow">다른 상황에서 한 번 더</span><h1>이번엔 자리가<br>달라졌어요.</h1><p>아래 표현에 맞는 곳에 놓인 물건을 골라 주세요.</p><div class="transfer-prompt" lang="ja">${episode.transfer.prompt}</div>${transferScene()}${e.feedback ? `<div class="feedback ${e.transfer === "passed" ? "success" : ""}" role="status">${esc(e.feedback)}</div>` : ""}${e.transfer === "passed" ? button(`배운 표현 정리하기 ${icon("arrow")}`, "next") : dog("버튼의 자리가 아니라, 창문과 물건의 관계를 봐 줘.", "think")}</section>`;
  if (e.step === "summary")
    body = `<section class="reading summary"><span class="completion">${icon("check")}</span><span class="eyebrow">사건 01 · 마무리</span><h1>작은 메모가<br>말이 되는 순간.</h1>${dog("오늘은 두 표현을 만났어.<br>다음에 만나면 더 반가울 거야.", "celebrate")}<div class="summary-expressions">${expressions.map((x) => `<div><b lang="ja">${x.text}</b><span>${x.meaning}</span></div>`).join("")}</div><p class="muted">다른 배치에서도 위치 표현을 확인했어요.<br>오늘 만난 표현은 복습 노트에 남겨 둘게요.</p>${button(`표현 다시 보기 ${icon("arrow")}`, "review")}${button("홈으로 돌아가기", "home", "secondary")}${button("사건 다시 플레이", "restart", "text-button")}</section>`;
  return `${top("사건 01", true)}<main class="play"><div class="play-heading"><span>카페에 남겨진 가방</span>${button(icon("note"), "notebook", "icon-button", 'aria-label="단서 노트 열기"')}</div><ol class="steps" aria-label="사건 진행">${labels.map((l, i) => `<li class="${i <= progress() ? "filled" : ""}" ${i === progress() ? 'aria-current="step"' : ""}><span class="sr-only">${l}</span></li>`).join("")}</ol>${body}</main>`;
}
function render(scroll = false) {
  const focus = document.activeElement?.dataset;
  document.documentElement.style.setProperty(
    "--text-scale",
    state.settings.textScale,
  );
  document.documentElement.dataset.motion = state.settings.motion;
  app.innerHTML = `<div class="shell">${storageError ? `<aside class="storage-warning" role="status">${esc(storageError)}</aside>` : ""}${{ start, onboarding, home, stories, review, my, play }[view]()}${toast ? `<div class="toast" role="status">${esc(toast)}</div>` : ""}</div>`;
  if (scroll) window.scrollTo(0, 0);
  else if (focus?.action)
    app
      .querySelector(
        `[data-action="${focus.action}"]${focus.id ? `[data-id="${focus.id}"]` : ""}`,
      )
      ?.focus({ preventScroll: true });
}
async function openPanel(kind, id) {
  player.stop();
  panelTrigger = document.activeElement;
  panelKind = kind;
  const { renderPanel } = await import("./panels.js");
  panel.innerHTML = renderPanel(kind, state, id);
  if (!panel.open) panel.showModal();
  panel.querySelector("button")?.focus();
}
function closePanel() {
  panel.close();
  panelKind = "";
  if (panelTrigger?.isConnected) panelTrigger.focus();
  else app.querySelector('[data-action="settings"]')?.focus();
}
async function handle(event) {
  const el = event.target.closest("[data-action]");
  if (!el || el.disabled) return;
  const a = el.dataset.action,
    id = el.dataset.id;
  if (["home", "stories", "review", "my"].includes(a)) {
    navigate(a);
    return;
  }
  if (a === "start") {
    navigate(state.onboarded ? "home" : "onboarding");
    return;
  }
  if (a === "support") {
    support = id;
    render();
    return;
  }
  if (a === "onboard") {
    commit({ type: "onboard", value: support });
    navigate("home");
    return;
  }
  if (a === "play") {
    commit({ type: "start" });
    navigate("play");
    return;
  }
  if (a === "next") {
    const now = performance.now();
    if (now - lastAdvance < 450) return;
    lastAdvance = now;
    player.stop();
    commit({ type: "next" });
    render(true);
    return;
  }
  if (a === "select") {
    commit({ type: "select", id });
    render();
    return;
  }
  if (a === "submit") {
    commit({ type: "submit" });
    render(state.episode.solved);
    return;
  }
  if (a === "clue") {
    commit({ type: "clue", id });
    render();
    await openPanel("clue", id);
    return;
  }
  if (a === "transfer") {
    commit({ type: "transfer", id });
    render();
    return;
  }
  if (
    a === "notebook" ||
    a === "settings" ||
    a === "restart" ||
    a === "reset"
  ) {
    await openPanel(a);
    return;
  }
  if (a === "hint") {
    commit({ type: "hint" });
    await openPanel("hint");
    return;
  }
  if (a === "more-hint") {
    commit({ type: "hint" });
    const { renderPanel } = await import("./panels.js");
    panel.innerHTML = renderPanel("hint", state);
    panel.querySelector('[data-action="more-hint"]:not(:disabled)')?.focus();
    return;
  }
  if (a === "close") {
    closePanel();
    return;
  }
  if (a === "confirm-restart") {
    commit({ type: "restart" });
    closePanel();
    navigate("play");
    return;
  }
  if (a === "confirm-reset") {
    try {
      reset(storage);
      state = freshState();
      support = state.support;
      blocked = false;
      storageError = "";
      closePanel();
      navigate("start");
    } catch {
      panel.querySelector('[role="status"]').textContent =
        "저장소에 접근할 수 없어 초기화하지 못했어요.";
    }
    return;
  }
  if (a === "export") {
    let raw;
    try {
      raw = storage.getItem(STORAGE_KEY) || JSON.stringify(state);
    } catch {
      raw = JSON.stringify(state);
    }
    const url = URL.createObjectURL(
      new Blob([raw], { type: "application/json" }),
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = "seodang-prototype-record.json";
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return;
  }
  if (a === "motion") {
    commit({
      type: "setting",
      key: "motion",
      value: state.settings.motion === "off" ? "system" : "off",
    });
    render();
    return;
  }
  if (a === "audio") {
    await player.play(audioManifest[id], state.settings.sound, (message) => {
      toast = message;
      render();
    });
  }
}
app.addEventListener("click", handle);
panel.addEventListener("click", handle);
panel.addEventListener("cancel", (event) => {
  event.preventDefault();
  closePanel();
});
panel.addEventListener("change", (event) => {
  const el = event.target,
    key = el.dataset.setting;
  if (key) {
    player.stop();
    commit({
      type: "setting",
      key,
      value:
        el.type === "checkbox"
          ? el.checked
          : key === "textScale"
            ? Number(el.value)
            : el.value,
    });
    render();
  }
});
window.addEventListener("pagehide", () => player.stop());
window.addEventListener("storage", (e) => {
  if (e.key === STORAGE_KEY) {
    blocked = true;
    storageError =
      "다른 탭에서 기록이 바뀌었어요. 충돌을 막기 위해 저장을 멈췄어요. 새로고침하면 최신 기록을 불러옵니다.";
    render();
  }
});
render();
