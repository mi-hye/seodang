import { episode, expressions } from "./content.js";
export const freshEpisode = () => ({
  contentVersion: 1,
  started: false,
  step: "intro",
  dialogue: 0,
  lesson: 0,
  clues: [],
  selected: null,
  attempts: 0,
  hintLevel: 0,
  solved: false,
  transfer: "not_attempted",
  transferAttempts: 0,
  feedback: "",
});
export const freshState = () => ({
  schemaVersion: 1,
  courseDirection: "ko-ja",
  onboarded: false,
  support: "beginner",
  settings: { sound: true, motion: "system", textScale: 1 },
  episode: freshEpisode(),
  encountered: [],
});
export function reduce(state, action) {
  const s = structuredClone(state),
    e = s.episode;
  switch (action.type) {
    case "onboard":
      s.onboarded = true;
      s.support = action.value;
      break;
    case "start":
      e.started = true;
      break;
    case "next":
      e.started = true;
      if (e.step === "intro") {
        if (e.dialogue < episode.intro.length - 1) e.dialogue++;
        else e.step = "learn";
      } else if (e.step === "learn") {
        s.encountered = [
          ...new Set([...s.encountered, expressions[e.lesson].id]),
        ];
        if (e.lesson < expressions.length - 1) e.lesson++;
        else e.step = "investigate";
      } else if (e.step === "solved") e.step = "transfer";
      else if (e.step === "transfer" && e.transfer === "passed")
        e.step = "summary";
      break;
    case "clue":
      if (
        e.step === "investigate" &&
        episode.clues.some((c) => c.id === action.id)
      ) {
        e.clues = [...new Set([...e.clues, action.id])];
        e.feedback = "단서 노트에 기록했어요.";
      }
      break;
    case "select":
      if (
        e.step === "investigate" &&
        episode.objects.some((o) => o.id === action.id)
      ) {
        e.selected = action.id;
        e.feedback = "";
      }
      break;
    case "submit":
      if (e.step !== "investigate") break;
      if (e.clues.length < 2) {
        e.feedback =
          "아직 확인하지 않은 메모가 있어요. 앞면과 뒷면, 두 단서를 먼저 모아 주세요.";
        break;
      }
      if (!e.selected) {
        e.feedback = "전달할 가방을 먼저 선택해 주세요.";
        break;
      }
      e.attempts++;
      const o = episode.objects.find((o) => o.id === e.selected);
      if (o.color !== "blue")
        e.feedback =
          "위치는 맞아요. 색을 나타내는 あおい를 다시 확인해 볼까요?";
      else if (o.place !== "window")
        e.feedback =
          "색은 맞아요. 위치를 나타내는 まどの そば를 다시 확인해 볼까요?";
      else {
        e.solved = true;
        e.step = "solved";
        e.feedback = "";
      }
      break;
    case "hint":
      e.hintLevel = Math.min(3, e.hintLevel + 1);
      break;
    case "transfer":
      if (e.step !== "transfer" || e.transfer === "passed") break;
      e.transferAttempts++;
      e.transfer = action.id === episode.transfer.answer ? "passed" : "retry";
      e.feedback =
        e.transfer === "passed"
          ? "맞아요. 창문이 오른쪽으로 옮겨져도 まどの そば는 창문 가까이를 뜻해요."
          : "이번에는 창문이 오른쪽에 있어요. まどの そば는 창문 옆이에요. 가까이 놓인 물건을 다시 골라 보세요.";
      break;
    case "setting":
      if (Object.hasOwn(s.settings, action.key))
        s.settings[action.key] = action.value;
      break;
    case "restart":
      s.episode = freshEpisode();
      break;
  }
  return s;
}
